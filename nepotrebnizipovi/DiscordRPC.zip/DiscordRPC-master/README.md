# DiscordRPC
A simple Rich Presence customised and open source for your FiveM and LiteM servers :)

# GNU LICENCA
Ovaj program je 'free of use' i možete ga forkati, a inače sve kopije će biti sankcionirane

# Discord ID
Moj discord tag je: sync.eye#2817
