USE `es_extended`;

INSERT INTO `items` (`name`, `label`, `weight`) VALUES
	('bread', 'Chleb', 1),
	('water', 'Woda', 1)
;
