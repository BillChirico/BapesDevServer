fx_version 'adamant'

game 'gta5'

description 'ESX Animations'

version '1.0.0'

client_scripts {
	'config.lua',
	'client/main.lua'
}

dependency 'es_extended'
