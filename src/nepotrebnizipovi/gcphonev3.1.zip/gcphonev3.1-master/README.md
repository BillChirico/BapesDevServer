# gcphonev3.1
GcPhone, updated for the newest ESX 

# GNU Licenca
Ovaj projekt je kopija od orginalnog gcphonea i v3 i stavljen je pod GNU licencu

# Requirements
PLEASE USE MY esx_addons_gcphone IF YOU HAVE PROBLEMS WITH NUMBERS OR JUST USE IT IF THIS IS YOUR 1ST DOWNLOAD

Official website new_banking -> https://github.com/NewWayRP/new_banking

# Credits
ElBichop (Creador) @GuidesJaen

Mureno (Colaborador) @murenooo

Paty Blue (Diseñadora gráfica) @psasfer

Sync (Repaired this thing) @_daamjan_

Sanlaris (Colaboradora) @Sanlaris_game

Original GCPhone by Gannon https://github.com/N3MTV/gcphone
