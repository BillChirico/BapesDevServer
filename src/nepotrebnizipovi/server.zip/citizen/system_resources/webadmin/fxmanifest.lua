fx_version 'adamant'
games { 'common' }

clr_disable_task_scheduler 'yes'

server_script 'server/**/publish/*.net.dll'